import BoardForm from './BoardForm';

const Layout = () => {
  return (
    <>
      <BoardForm></BoardForm>;
    </>
  );
};

export default Layout;
